KafkaClient
===========

.. autoclass:: kafka.KafkaClient
    :members:
