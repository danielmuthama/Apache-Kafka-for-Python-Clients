KafkaAdminClient
===========

.. autoclass:: kafka.KafkaAdminClient
    :members:
